# ywcai 042516
# Test module of code sql_shiny
# First half part: examples of input list
# Second half part: Supposed output test
# Stable connection is needed for success test

source(file = "sql_shiny.R")

# Examples
input_ex1<-list(variantinputtype=1, view=1,
                selectCollum1=c("variant_id","chrom","pos","strain_name","allele","prob","is_max","consequence","gene_name","transcript_name"),
                chr="X",
                strnum=31000000,
                endnum=32000000,
                prob_cutoff="0.5",
                ismax=1,
                homo="Homo",
                variantfile="",
                strainlistnew=c(1,2,3,4),
                variant_id_text="1,2",
                limnum=1000)

input_ex2<-list(view=3,
                selectCollum3=c("variant_id","chrom","pos","gene_name","strain_name","allele","prob"),
                chr="ALL",
                strnum=31000000,
                endnum=32000000,
                prob_cutoff="0",
                ismax=1,
                homo="ALL",
                variantfile="",
                strainp1new=c(1),
                strainp2new=c(2),
                limnum=1000)

generateQuery(input_ex1)
generateQuery(input_ex2)
