# Use to generate all tables for shiny
library(RMySQL)
library("biomaRt")

setwd("/Users/Yan2015/Dropbox/UNC/ValdarLab/dbpro/nutridiallel2014/src/genomerep/variantdb/dbgui/shiny")

con <- dbConnect(RMySQL::MySQL(), dbname = "exon_1410b", username='root',password='FrozenMixedVegetables',host="127.0.0.1",port=3308)

# Strain
strain_list_raw<-dbGetQuery(con,"select * from strain")
write.csv(strain_list_raw,"ccstrainmapid.csv",quote=FALSE,row.names = FALSE)

# Gene
mouse = useMart("ensembl", dataset = "mmusculus_gene_ensembl")

gene_list_raw<-dbGetQuery(con,"select * from gene")
genes <- gene_list_raw$gene_name

G_list <- getBM(filters= c("ensembl_gene_id"), attributes= c("ensembl_gene_id","mgi_symbol"),values=genes,mart= mouse)
gene_merge_list<-merge(gene_list_raw,G_list,by.x="gene_name",by.y="ensembl_gene_id",all=TRUE)

write.csv(gene_merge_list,"genelist.csv",quote=FALSE,row.names = FALSE)
